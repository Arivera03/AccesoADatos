package Repaso.Arraylist;

public class Producto {
    private String nombre;
    private double precio;

    public Producto(String n, double p) {
        nombre = n;
        precio = p;
    }

    public String getNombre() {
        return nombre;
    }

    public double getPrecio() {
        return precio;
    }
}
